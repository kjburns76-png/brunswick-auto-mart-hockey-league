import { useState, useMemo, useEffect } from 'react';
import { ChevronUp, ChevronDown, ChevronsUpDown } from 'lucide-react';
import { getStats, type StatEntry } from '../utils/dataStore';

type SortKey = 'name' | 'gamesPlayed' | 'goals' | 'assists' | 'points' | 'pim';
type SortDir = 'asc' | 'desc';

const columns: { key: SortKey; label: string; abbr: string; numeric: boolean }[] = [
  { key: 'name',        label: 'Player',         abbr: 'Player', numeric: false },
  { key: 'gamesPlayed', label: 'Games Played',    abbr: 'GP',     numeric: true  },
  { key: 'goals',       label: 'Goals',           abbr: 'G',      numeric: true  },
  { key: 'assists',     label: 'Assists',         abbr: 'A',      numeric: true  },
  { key: 'points',      label: 'Points',          abbr: 'PTS',    numeric: true  },
  { key: 'pim',         label: 'Penalty Minutes', abbr: 'PIM',    numeric: true  },
];

function SortIcon({ col, sortKey, sortDir }: { col: SortKey; sortKey: SortKey; sortDir: SortDir }) {
  if (col !== sortKey) return <ChevronsUpDown className="w-3.5 h-3.5 opacity-40" />;
  return sortDir === 'asc'
    ? <ChevronUp className="w-3.5 h-3.5 text-team-teal" />
    : <ChevronDown className="w-3.5 h-3.5 text-team-teal" />;
}

export default function StatsPage() {
  const [stats, setStats] = useState<StatEntry[]>(() => getStats());
  const [sortKey, setSortKey] = useState<SortKey>('name');
  const [sortDir, setSortDir] = useState<SortDir>('asc');

  useEffect(() => {
    function onUpdate() {
      setStats(getStats());
    }
    window.addEventListener('storage', onUpdate);
    window.addEventListener('triceratops:update', onUpdate);
    return () => {
      window.removeEventListener('storage', onUpdate);
      window.removeEventListener('triceratops:update', onUpdate);
    };
  }, []);

  const sortedStats = useMemo(() => {
    return [...stats].sort((a, b) => {
      let aVal: string | number;
      let bVal: string | number;

      if (sortKey === 'name') {
        aVal = a.name.toLowerCase();
        bVal = b.name.toLowerCase();
      } else {
        aVal = a[sortKey];
        bVal = b[sortKey];
      }

      if (aVal < bVal) return sortDir === 'asc' ? -1 : 1;
      if (aVal > bVal) return sortDir === 'asc' ? 1 : -1;
      return 0;
    });
  }, [stats, sortKey, sortDir]);

  function handleSort(key: SortKey) {
    if (sortKey === key) {
      setSortDir(d => d === 'asc' ? 'desc' : 'asc');
    } else {
      setSortKey(key);
      setSortDir(key === 'name' ? 'asc' : 'desc');
    }
  }

  function getStatHighlight(stat: StatEntry, key: SortKey): boolean {
    if (key === 'name') return false;
    const max = Math.max(...stats.map(s => s[key] as number));
    return (stat[key] as number) === max && max > 0;
  }

  return (
    <section className="container mx-auto px-4 py-10 bg-gradient-to-b from-team-teal/5 to-transparent">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="h-8 w-1.5 bg-team-teal" />
          <h2 className="font-heading text-4xl md:text-5xl text-team-white">Player Stats</h2>
        </div>
        <p className="text-muted-foreground ml-5 font-body">
          2024–2025 Season · Click column headers to sort
        </p>
      </div>

      <div className="overflow-x-auto rounded border border-border">
        <table className="w-full min-w-[600px]">
          <thead>
            <tr className="bg-team-teal/15 border-b-2 border-team-teal">
              {columns.map((col) => (
                <th
                  key={col.key}
                  onClick={() => handleSort(col.key)}
                  className={`
                    px-4 py-3 font-heading text-sm tracking-widest cursor-pointer select-none
                    transition-colors duration-150 hover:bg-team-teal/10
                    ${col.numeric ? 'text-center' : 'text-left'}
                    ${sortKey === col.key ? 'text-team-teal' : 'text-team-white/70'}
                  `}
                >
                  <span className="inline-flex items-center gap-1.5">
                    <span>{col.abbr}</span>
                    <SortIcon col={col.key} sortKey={sortKey} sortDir={sortDir} />
                  </span>
                </th>
              ))}
            </tr>
          </thead>
          <tbody>
            {sortedStats.map((stat, idx) => (
              <tr
                key={stat.playerId}
                className={`
                  border-b border-border transition-colors duration-150
                  ${idx % 2 === 0 ? 'bg-card' : 'bg-team-teal/[0.03]'}
                  hover:bg-team-teal/10
                `}
              >
                <td className="px-4 py-3">
                  <div className="flex items-center gap-2">
                    <div className="w-7 h-7 rounded-sm bg-team-teal/10 border border-team-teal/30 flex items-center justify-center shrink-0">
                      <span className="font-heading text-xs text-team-teal">{idx + 1}</span>
                    </div>
                    <span className="font-heading text-base text-team-white">{stat.name}</span>
                  </div>
                </td>
                <td className="px-4 py-3 text-center">
                  <span className={`font-heading text-lg ${getStatHighlight(stat, 'gamesPlayed') ? 'text-team-teal' : 'text-team-white/80'}`}>
                    {stat.gamesPlayed}
                  </span>
                </td>
                <td className="px-4 py-3 text-center">
                  <span className={`font-heading text-lg ${getStatHighlight(stat, 'goals') ? 'text-team-teal font-bold' : 'text-team-white/80'}`}>
                    {stat.goals}
                  </span>
                </td>
                <td className="px-4 py-3 text-center">
                  <span className={`font-heading text-lg ${getStatHighlight(stat, 'assists') ? 'text-team-teal font-bold' : 'text-team-white/80'}`}>
                    {stat.assists}
                  </span>
                </td>
                <td className="px-4 py-3 text-center">
                  <span className={`font-heading text-lg ${getStatHighlight(stat, 'points') ? 'text-team-teal font-bold' : 'text-team-white/80'}`}>
                    {stat.points}
                  </span>
                </td>
                <td className="px-4 py-3 text-center">
                  <span className={`font-heading text-lg ${getStatHighlight(stat, 'pim') ? 'text-team-teal font-bold' : 'text-team-white/80'}`}>
                    {stat.pim}
                  </span>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
