import { useState } from 'react';
import { Lock, Plus, Trash2, Save, Users, Calendar, BarChart2, Newspaper, Settings } from 'lucide-react';
import PasswordGate from '../components/PasswordGate';
import {
  getPlayers, savePlayers, getGames, saveGames, getStats, saveStats, getNews, saveNews, genId,
  getSeason, saveSeason,
  type Player, type Game, type GameResult, type StatEntry, type NewsItem,
} from '../utils/dataStore';

const ADMIN_PASSWORD = 'Bubbakellen2!';

function notify() {
  window.dispatchEvent(new Event('triceratops:update'));
}

function useAdminAuth() {
  const [isAdmin, setIsAdmin] = useState(() => {
    return sessionStorage.getItem('caffeineAdminToken') === ADMIN_PASSWORD;
  });
  const handleAuthenticated = () => setIsAdmin(true);
  const handleLogout = () => {
    sessionStorage.removeItem('caffeineAdminToken');
    setIsAdmin(false);
  };
  return { isAdmin, handleAuthenticated, handleLogout };
}

// ─── Input / Select helpers ───────────────────────────────────────────────────

const inputCls = 'w-full px-3 py-2 rounded bg-black border border-zinc-700 text-white placeholder-zinc-500 font-body text-sm focus:outline-none focus:border-team-teal';
const selectCls = `${inputCls} cursor-pointer`;
const btnPrimary = 'flex items-center gap-2 px-4 py-2 bg-team-teal text-team-black rounded font-heading text-sm tracking-wide hover:bg-team-teal/80 transition-colors';
const btnDanger  = 'flex items-center gap-2 px-3 py-1.5 border border-red-700/60 text-red-400 rounded font-body text-xs hover:bg-red-900/20 transition-colors';

// ─── Section: Roster ─────────────────────────────────────────────────────────

function RosterSection() {
  const [players, setPlayers] = useState<Player[]>(() => getPlayers());
  const [form, setForm] = useState({ number: '', name: '', position: 'Forward', hometown: '', photo: '', height: '', weight: '', age: '' });
  const [editId, setEditId] = useState<string | null>(null);

  function persist(updated: Player[]) {
    savePlayers(updated);
    setPlayers(updated);
    notify();
  }

  function startEdit(p: Player) {
    setEditId(p.id);
    setForm({ number: String(p.number), name: p.name, position: p.position, hometown: p.hometown, photo: p.photo || '', height: p.height || '', weight: p.weight || '', age: p.age ? String(p.age) : '' });
  }

  function cancelEdit() {
    setEditId(null);
    setForm({ number: '', name: '', position: 'Forward', hometown: '', photo: '', height: '', weight: '', age: '' });
  }

  function saveEdit() {
    if (!editId) return;
    persist(players.map(p => p.id === editId
      ? { ...p, number: Number(form.number), name: form.name, position: form.position, hometown: form.hometown, photo: form.photo, height: form.height, weight: form.weight, age: form.age ? Number(form.age) : undefined }
      : p
    ));
    cancelEdit();
  }

  function addPlayer() {
    if (!form.name.trim()) return;
    const newPlayer: Player = { id: genId(), number: Number(form.number) || 0, name: form.name, position: form.position, hometown: form.hometown, photo: form.photo, height: form.height, weight: form.weight, age: form.age ? Number(form.age) : undefined };
    persist([...players, newPlayer]);
    setForm({ number: '', name: '', position: 'Forward', hometown: '', photo: '', height: '', weight: '', age: '' });
  }

  function removePlayer(id: string) {
    persist(players.filter(p => p.id !== id));
  }

  return (
    <div className="space-y-6">
      {/* Add / Edit form */}
      <div className="p-4 bg-black border border-zinc-700 rounded">
        <h3 className="font-heading text-team-teal text-lg mb-4">{editId ? 'Edit Player' : 'Add Player'}</h3>
        <div className="grid grid-cols-2 gap-3 mb-3">
          <label className="block">
            <span className="block font-body text-zinc-400 text-xs mb-1">Jersey #</span>
            <input type="number" className={inputCls} placeholder="12" value={form.number}
              onChange={e => setForm(f => ({ ...f, number: e.target.value }))} />
          </label>
          <label className="block">
            <span className="block font-body text-zinc-400 text-xs mb-1">Name</span>
            <input type="text" className={inputCls} placeholder="Player Name" value={form.name}
              onChange={e => setForm(f => ({ ...f, name: e.target.value }))} />
          </label>
          <label className="block">
            <span className="block font-body text-zinc-400 text-xs mb-1">Position</span>
            <select className={selectCls} value={form.position}
              onChange={e => setForm(f => ({ ...f, position: e.target.value }))}>
              <option value="Forward">Forward</option>
              <option value="Defense">Defense</option>
              <option value="Goalie">Goalie</option>
            </select>
          </label>
          <label className="block">
            <span className="block font-body text-zinc-400 text-xs mb-1">Hometown</span>
            <input type="text" className={inputCls} placeholder="City, ST" value={form.hometown}
              onChange={e => setForm(f => ({ ...f, hometown: e.target.value }))} />
          </label>
          <label className="block">
            <span className="block font-body text-zinc-400 text-xs mb-1">Height</span>
            <input type="text" className={inputCls} placeholder='5&apos;10"' value={form.height}
              onChange={e => setForm(f => ({ ...f, height: e.target.value }))} />
          </label>
          <label className="block">
            <span className="block font-body text-zinc-400 text-xs mb-1">Weight (lbs)</span>
            <input type="text" className={inputCls} placeholder="185 lbs" value={form.weight}
              onChange={e => setForm(f => ({ ...f, weight: e.target.value }))} />
          </label>
          <label className="block">
            <span className="block font-body text-zinc-400 text-xs mb-1">Age</span>
            <input type="number" className={inputCls} placeholder="28" value={form.age}
              onChange={e => setForm(f => ({ ...f, age: e.target.value }))} />
          </label>
          <label className="block col-span-2">
            <span className="block font-body text-zinc-400 text-xs mb-1">Player Photo</span>
            <div className="flex items-center gap-3">
              <input
                type="file"
                accept="image/*"
                className="hidden"
                id="photo-upload"
                onChange={e => {
                  const file = e.target.files?.[0];
                  if (!file) return;
                  const reader = new FileReader();
                  reader.onload = () => setForm(f => ({ ...f, photo: reader.result as string }));
                  reader.readAsDataURL(file);
                }}
              />
              <label htmlFor="photo-upload" className="cursor-pointer px-3 py-2 border border-zinc-600 text-zinc-300 rounded font-body text-xs hover:border-team-teal hover:text-team-teal transition-colors">
                {form.photo ? 'Change Photo' : 'Upload Photo'}
              </label>
              {form.photo && (
                <img src={form.photo} alt="Preview" className="w-12 h-12 rounded-full object-cover border-2 border-team-teal/50" />
              )}
              {form.photo && (
                <button type="button" onClick={() => setForm(f => ({ ...f, photo: '' }))} className="text-zinc-500 hover:text-red-400 font-body text-xs">Remove</button>
              )}
            </div>
          </label>
        </div>
        <div className="flex gap-2">
          {editId ? (
            <>
              <button type="button" onClick={saveEdit} className={btnPrimary}><Save className="w-4 h-4" /> Save Changes</button>
              <button type="button" onClick={cancelEdit} className="px-4 py-2 border border-zinc-600 text-zinc-400 rounded font-body text-sm hover:border-zinc-400 transition-colors">Cancel</button>
            </>
          ) : (
            <button type="button" onClick={addPlayer} className={btnPrimary}><Plus className="w-4 h-4" /> Add Player</button>
          )}
        </div>
      </div>

      {/* Player list */}
      <div className="space-y-2">
        {players.slice().sort((a, b) => a.number - b.number).map(p => (
          <div key={p.id} className="flex items-center gap-3 p-3 bg-black border border-zinc-700 rounded">
            <span className="font-heading text-team-teal w-10 text-center">#{p.number}</span>
            <div className="flex-1 min-w-0">
              <span className="font-heading text-white">{p.name}</span>
              <span className="ml-2 font-body text-zinc-400 text-sm">{p.position} · {p.hometown}</span>
            </div>
            <button type="button" onClick={() => startEdit(p)} className="px-3 py-1.5 border border-zinc-600 text-zinc-300 rounded font-body text-xs hover:border-team-teal hover:text-team-teal transition-colors">Edit</button>
            <button type="button" onClick={() => removePlayer(p.id)} className={btnDanger}><Trash2 className="w-3 h-3" /></button>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Section: Schedule ───────────────────────────────────────────────────────

function ScheduleSection() {
  const [games, setGames] = useState<Game[]>(() => getGames());
  const [form, setForm] = useState({ date: '', time: '', opponent: '', home: true, result: 'tbd' as GameResult });
  const [editId, setEditId] = useState<string | null>(null);

  function persist(updated: Game[]) {
    saveGames(updated);
    setGames(updated);
    notify();
  }

  function startEdit(g: Game) {
    setEditId(g.id);
    setForm({ date: g.date, time: g.time, opponent: g.opponent, home: g.home, result: g.result });
  }

  function cancelEdit() {
    setEditId(null);
    setForm({ date: '', time: '', opponent: '', home: true, result: 'tbd' });
  }

  function saveEdit() {
    if (!editId) return;
    persist(games.map(g => g.id === editId ? { ...g, ...form } : g));
    cancelEdit();
  }

  function addGame() {
    const newGame: Game = { id: genId(), date: form.date || 'TBD', time: form.time || 'TBD', opponent: form.opponent || 'TBD', home: form.home, result: form.result };
    persist([...games, newGame]);
    setForm({ date: '', time: '', opponent: '', home: true, result: 'tbd' });
  }

  function removeGame(id: string) {
    persist(games.filter(g => g.id !== id));
  }

  return (
    <div className="space-y-6">
      <div className="p-4 bg-black border border-zinc-700 rounded">
        <h3 className="font-heading text-team-teal text-lg mb-4">{editId ? 'Edit Game' : 'Add Game'}</h3>
        <div className="grid grid-cols-2 gap-3 mb-3">
          <label className="block">
            <span className="block font-body text-zinc-400 text-xs mb-1">Date</span>
            <input type="text" className={inputCls} placeholder="Mar 15, 2025" value={form.date}
              onChange={e => setForm(f => ({ ...f, date: e.target.value }))} />
          </label>
          <label className="block">
            <span className="block font-body text-zinc-400 text-xs mb-1">Time</span>
            <input type="text" className={inputCls} placeholder="7:00 PM" value={form.time}
              onChange={e => setForm(f => ({ ...f, time: e.target.value }))} />
          </label>
          <label className="block">
            <span className="block font-body text-zinc-400 text-xs mb-1">Opponent</span>
            <input type="text" className={inputCls} placeholder="Team Name" value={form.opponent}
              onChange={e => setForm(f => ({ ...f, opponent: e.target.value }))} />
          </label>
          <label className="block">
            <span className="block font-body text-zinc-400 text-xs mb-1">Location</span>
            <select className={selectCls} value={form.home ? 'home' : 'away'}
              onChange={e => setForm(f => ({ ...f, home: e.target.value === 'home' }))}>
              <option value="home">Home</option>
              <option value="away">Away</option>
            </select>
          </label>
          <label className="block">
            <span className="block font-body text-zinc-400 text-xs mb-1">Result</span>
            <select className={selectCls} value={form.result}
              onChange={e => setForm(f => ({ ...f, result: e.target.value as GameResult }))}>
              <option value="tbd">TBD</option>
              <option value="win">Win</option>
              <option value="loss">Loss</option>
            </select>
          </label>
        </div>
        <div className="flex gap-2">
          {editId ? (
            <>
              <button type="button" onClick={saveEdit} className={btnPrimary}><Save className="w-4 h-4" /> Save Changes</button>
              <button type="button" onClick={cancelEdit} className="px-4 py-2 border border-zinc-600 text-zinc-400 rounded font-body text-sm hover:border-zinc-400 transition-colors">Cancel</button>
            </>
          ) : (
            <button type="button" onClick={addGame} className={btnPrimary}><Plus className="w-4 h-4" /> Add Game</button>
          )}
        </div>
      </div>

      <div className="space-y-2">
        {games.map((g, idx) => (
          <div key={g.id} className="flex items-center gap-3 p-3 bg-black border border-zinc-700 rounded">
            <span className="font-heading text-zinc-500 w-6 text-center text-sm">{idx + 1}</span>
            <div className="flex-1 min-w-0">
              <span className="font-heading text-white">{g.opponent && g.opponent !== 'TBD' ? `vs. ${g.opponent}` : 'Opponent TBD'}</span>
              <span className="ml-2 font-body text-zinc-400 text-sm">{g.date} · {g.time} · {g.home ? 'Home' : 'Away'}</span>
              <span className={`ml-2 font-heading text-xs tracking-wide ${g.result === 'win' ? 'text-team-teal' : g.result === 'loss' ? 'text-red-400' : 'text-zinc-500'}`}>
                {g.result.toUpperCase()}
              </span>
            </div>
            <button type="button" onClick={() => startEdit(g)} className="px-3 py-1.5 border border-zinc-600 text-zinc-300 rounded font-body text-xs hover:border-team-teal hover:text-team-teal transition-colors">Edit</button>
            <button type="button" onClick={() => removeGame(g.id)} className={btnDanger}><Trash2 className="w-3 h-3" /></button>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Section: Stats ──────────────────────────────────────────────────────────

function StatsSection() {
  const [stats, setStats] = useState<StatEntry[]>(() => getStats());

  function handleChange(playerId: string, field: keyof StatEntry, value: string) {
    setStats(prev => prev.map(s => s.playerId === playerId ? { ...s, [field]: field === 'name' ? value : Number(value) } : s));
  }

  function handleSave(entry: StatEntry) {
    const updated = stats.map(s => s.playerId === entry.playerId ? entry : s);
    saveStats(updated);
    setStats(updated);
    notify();
  }

  return (
    <div className="space-y-3">
      {stats.map(s => (
        <div key={s.playerId} className="p-4 bg-black border border-zinc-700 rounded">
          <div className="font-heading text-white mb-3">{s.name}</div>
          <div className="grid grid-cols-3 sm:grid-cols-5 gap-3 mb-3">
            {(['gamesPlayed', 'goals', 'assists', 'points', 'pim'] as const).map(field => (
              <label key={field} className="block">
                <span className="block font-body text-zinc-400 text-xs mb-1 uppercase tracking-wide">{field === 'gamesPlayed' ? 'GP' : field === 'pim' ? 'PIM' : field.charAt(0).toUpperCase() + field.slice(1)}</span>
                <input
                  type="number"
                  className={inputCls}
                  value={s[field]}
                  onChange={e => handleChange(s.playerId, field, e.target.value)}
                />
              </label>
            ))}
          </div>
          <button type="button" onClick={() => handleSave(s)} className={btnPrimary}><Save className="w-4 h-4" /> Save</button>
        </div>
      ))}
    </div>
  );
}

// ─── Section: News ───────────────────────────────────────────────────────────

function NewsSection() {
  const [items, setItems] = useState<NewsItem[]>(() => getNews());
  const [form, setForm] = useState({ title: '', body: '', publishedAt: '' });
  const [editId, setEditId] = useState<string | null>(null);

  function persist(updated: NewsItem[]) {
    saveNews(updated);
    setItems(updated);
    notify();
  }

  function startEdit(item: NewsItem) {
    setEditId(item.id);
    setForm({ title: item.title, body: item.body, publishedAt: item.publishedAt });
  }

  function cancelEdit() {
    setEditId(null);
    setForm({ title: '', body: '', publishedAt: '' });
  }

  function saveEdit() {
    if (!editId) return;
    persist(items.map(i => i.id === editId ? { ...i, ...form } : i));
    cancelEdit();
  }

  function addItem() {
    if (!form.title.trim()) return;
    const now = new Date().toLocaleDateString('en-US', { month: 'long', year: 'numeric' });
    const newItem: NewsItem = { id: genId(), title: form.title, body: form.body, publishedAt: form.publishedAt || now };
    persist([newItem, ...items]);
    setForm({ title: '', body: '', publishedAt: '' });
  }

  function removeItem(id: string) {
    persist(items.filter(i => i.id !== id));
  }

  return (
    <div className="space-y-6">
      <div className="p-4 bg-black border border-zinc-700 rounded">
        <h3 className="font-heading text-team-teal text-lg mb-4">{editId ? 'Edit Article' : 'Add Article'}</h3>
        <div className="space-y-3 mb-3">
          <label className="block">
            <span className="block font-body text-zinc-400 text-xs mb-1">Title</span>
            <input type="text" className={inputCls} placeholder="Article title" value={form.title}
              onChange={e => setForm(f => ({ ...f, title: e.target.value }))} />
          </label>
          <label className="block">
            <span className="block font-body text-zinc-400 text-xs mb-1">Date (e.g. March 2025)</span>
            <input type="text" className={inputCls} placeholder="Leave blank for today" value={form.publishedAt}
              onChange={e => setForm(f => ({ ...f, publishedAt: e.target.value }))} />
          </label>
          <label className="block">
            <span className="block font-body text-zinc-400 text-xs mb-1">Body</span>
            <textarea className={`${inputCls} h-24 resize-none`} placeholder="Article content..." value={form.body}
              onChange={e => setForm(f => ({ ...f, body: e.target.value }))} />
          </label>
        </div>
        <div className="flex gap-2">
          {editId ? (
            <>
              <button type="button" onClick={saveEdit} className={btnPrimary}><Save className="w-4 h-4" /> Save Changes</button>
              <button type="button" onClick={cancelEdit} className="px-4 py-2 border border-zinc-600 text-zinc-400 rounded font-body text-sm hover:border-zinc-400 transition-colors">Cancel</button>
            </>
          ) : (
            <button type="button" onClick={addItem} className={btnPrimary}><Plus className="w-4 h-4" /> Add Article</button>
          )}
        </div>
      </div>

      <div className="space-y-3">
        {items.map(item => (
          <div key={item.id} className="p-4 bg-black border border-zinc-700 rounded">
            <div className="flex items-start justify-between gap-3 mb-1">
              <span className="font-heading text-white">{item.title}</span>
              <span className="shrink-0 font-body text-zinc-500 text-xs">{item.publishedAt}</span>
            </div>
            <p className="font-body text-zinc-400 text-sm mb-3 leading-relaxed line-clamp-2">{item.body}</p>
            <div className="flex gap-2">
              <button type="button" onClick={() => startEdit(item)} className="px-3 py-1.5 border border-zinc-600 text-zinc-300 rounded font-body text-xs hover:border-team-teal hover:text-team-teal transition-colors">Edit</button>
              <button type="button" onClick={() => removeItem(item.id)} className={btnDanger}><Trash2 className="w-3 h-3" /> Delete</button>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Section: Settings ────────────────────────────────────────────────────────

function SettingsSection() {
  const [season, setSeason] = useState(() => getSeason());
  const [saved, setSaved] = useState(false);

  function handleSave() {
    saveSeason(season);
    notify();
    setSaved(true);
    setTimeout(() => setSaved(false), 2000);
  }

  return (
    <div className="space-y-6">
      <div className="p-4 bg-black border border-zinc-700 rounded">
        <h3 className="font-heading text-team-teal text-lg mb-4">Season Settings</h3>
        <div className="space-y-3 mb-4">
          <label className="block">
            <span className="block font-body text-zinc-400 text-xs mb-1">Current Season</span>
            <input
              type="text"
              className={inputCls}
              placeholder="2024-2025"
              value={season}
              onChange={e => setSeason(e.target.value)}
            />
            <span className="block font-body text-zinc-500 text-xs mt-1">
              e.g. 2024-2025 or 2025-2026
            </span>
          </label>
        </div>
        <button type="button" onClick={handleSave} className={btnPrimary}>
          <Save className="w-4 h-4" />
          {saved ? 'Saved!' : 'Save Season'}
        </button>
      </div>
    </div>
  );
}

// ─── Main Admin component ─────────────────────────────────────────────────────

type AdminTab = 'roster' | 'schedule' | 'stats' | 'news' | 'settings';

const adminTabs: { id: AdminTab; label: string; icon: React.ReactNode }[] = [
  { id: 'roster',   label: 'Roster',   icon: <Users className="w-4 h-4" /> },
  { id: 'schedule', label: 'Schedule', icon: <Calendar className="w-4 h-4" /> },
  { id: 'stats',    label: 'Stats',    icon: <BarChart2 className="w-4 h-4" /> },
  { id: 'news',     label: 'News',     icon: <Newspaper className="w-4 h-4" /> },
  { id: 'settings', label: 'Settings', icon: <Settings className="w-4 h-4" /> },
];

export default function Admin() {
  const { isAdmin, handleAuthenticated, handleLogout } = useAdminAuth();
  const [activeTab, setActiveTab] = useState<AdminTab>('roster');

  if (!isAdmin) {
    return (
      <PasswordGate
        correctPassword={ADMIN_PASSWORD}
        onAuthenticated={handleAuthenticated}
      />
    );
  }

  return (
    <section className="container mx-auto px-4 py-10 max-w-3xl">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="h-8 w-1.5 bg-team-teal" />
          <h2 className="font-heading text-4xl md:text-5xl text-team-white">Admin Panel</h2>
        </div>
        <p className="text-muted-foreground ml-5 font-body">
          Triceratops Hockey Club — Team Management
        </p>
      </div>

      {/* Tab bar */}
      <div className="flex gap-1 mb-6 bg-black p-1 rounded border border-zinc-700">
        {adminTabs.map(tab => (
          <button
            key={tab.id}
            type="button"
            onClick={() => setActiveTab(tab.id)}
            className={`flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded font-heading text-sm tracking-wide transition-colors ${
              activeTab === tab.id
                ? 'bg-team-teal text-team-black'
                : 'text-zinc-400 hover:text-white'
            }`}
          >
            {tab.icon}
            <span className="hidden sm:inline">{tab.label}</span>
          </button>
        ))}
      </div>

      {/* Section content */}
      {activeTab === 'roster'   && <RosterSection />}
      {activeTab === 'schedule' && <ScheduleSection />}
      {activeTab === 'stats'    && <StatsSection />}
      {activeTab === 'news'     && <NewsSection />}
      {activeTab === 'settings' && <SettingsSection />}

      {/* Logout */}
      <div className="flex justify-end mt-10">
        <button
          type="button"
          onClick={handleLogout}
          className="flex items-center gap-2 px-4 py-2 border border-border rounded text-muted-foreground hover:border-red-700/60 hover:text-red-400 transition-colors font-body text-sm"
        >
          <Lock className="w-4 h-4" />
          Lock Admin Panel
        </button>
      </div>
    </section>
  );
}
