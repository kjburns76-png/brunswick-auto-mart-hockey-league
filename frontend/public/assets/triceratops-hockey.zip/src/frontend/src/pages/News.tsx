import { useState, useEffect } from 'react';
import { Newspaper } from 'lucide-react';
import { getNews, type NewsItem } from '../utils/dataStore';

export default function News() {
  const [newsItems, setNewsItems] = useState<NewsItem[]>(() => getNews());

  useEffect(() => {
    function onUpdate() {
      setNewsItems(getNews());
    }
    window.addEventListener('storage', onUpdate);
    window.addEventListener('triceratops:update', onUpdate);
    return () => {
      window.removeEventListener('storage', onUpdate);
      window.removeEventListener('triceratops:update', onUpdate);
    };
  }, []);

  return (
    <section className="container mx-auto px-4 py-10 bg-gradient-to-b from-team-teal/5 to-transparent">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="h-8 w-1.5 bg-team-teal" />
          <h2 className="font-heading text-4xl md:text-5xl text-team-white">Team News</h2>
        </div>
        <p className="text-muted-foreground ml-5 font-body">
          Latest updates from the Triceratops Hockey Club
        </p>
      </div>

      {newsItems.length === 0 ? (
        <div className="text-center py-20">
          <Newspaper className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
          <p className="font-heading text-2xl text-muted-foreground">No news yet.</p>
          <p className="text-muted-foreground font-body mt-2">Check back soon for updates!</p>
        </div>
      ) : (
        <div className="space-y-6 max-w-3xl">
          {newsItems.map((item) => (
            <article
              key={item.id}
              className="p-6 bg-card border border-border border-l-4 border-l-team-teal/50 rounded hover:border-team-teal/60 hover:border-l-team-teal hover:bg-team-teal/5 transition-all duration-200"
            >
              <div className="flex items-start justify-between gap-4 mb-3">
                <h3 className="font-heading text-2xl text-team-white leading-tight">{item.title}</h3>
                <span className="shrink-0 text-xs font-body text-muted-foreground border border-border px-2 py-1 rounded-sm">
                  {item.publishedAt}
                </span>
              </div>
              <p className="font-body text-muted-foreground leading-relaxed">{item.body}</p>
            </article>
          ))}
        </div>
      )}
    </section>
  );
}
