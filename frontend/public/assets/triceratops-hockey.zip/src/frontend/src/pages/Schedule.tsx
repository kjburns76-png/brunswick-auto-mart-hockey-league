import { useState, useEffect } from 'react';
import { Calendar, Clock, MapPin, Trophy, Minus } from 'lucide-react';
import { getGames, getSeason, type Game, type GameResult } from '../utils/dataStore';

function ResultBadge({ result }: { result: GameResult }) {
  if (result === 'win') {
    return (
      <span className="inline-flex items-center gap-1 px-3 py-1 rounded-sm bg-team-teal/20 border border-team-teal text-team-teal font-heading text-sm tracking-widest">
        <Trophy className="w-3 h-3" />
        WIN
      </span>
    );
  }
  if (result === 'loss') {
    return (
      <span className="inline-flex items-center gap-1 px-3 py-1 rounded-sm bg-red-900/20 border border-red-700/60 text-red-400 font-heading text-sm tracking-widest">
        <Minus className="w-3 h-3" />
        LOSS
      </span>
    );
  }
  return (
    <span className="inline-flex items-center gap-1 px-3 py-1 rounded-sm bg-muted/40 border border-border text-muted-foreground font-heading text-sm tracking-widest">
      TBD
    </span>
  );
}

export default function Schedule() {
  const [games, setGames] = useState<Game[]>(() => getGames());
  const [season, setSeason] = useState(() => getSeason());

  useEffect(() => {
    function onStorage() {
      setGames(getGames());
      setSeason(getSeason());
    }
    window.addEventListener('storage', onStorage);
    window.addEventListener('triceratops:update', onStorage);
    return () => {
      window.removeEventListener('storage', onStorage);
      window.removeEventListener('triceratops:update', onStorage);
    };
  }, []);

  return (
    <section className="container mx-auto px-4 py-10 bg-gradient-to-b from-team-teal/5 to-transparent">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="h-8 w-1.5 bg-team-teal" />
          <h2 className="font-heading text-4xl md:text-5xl text-team-white">Game Schedule</h2>
        </div>
        <p className="text-muted-foreground ml-5 font-body">
          {season} BAMHL Season
        </p>
      </div>

      {/* Win / Loss / TBD record strip */}
      {(() => {
        const wins   = games.filter(g => g.result === 'win').length;
        const losses = games.filter(g => g.result === 'loss').length;
        const tbd    = games.filter(g => g.result === 'tbd').length;
        return (
          <div className="flex items-stretch gap-0 mb-6 overflow-hidden rounded border border-team-teal/30 bg-black/60">
            {[
              { label: 'W',   value: wins,   cls: 'text-team-teal border-r border-team-teal/20' },
              { label: 'L',   value: losses, cls: 'text-red-400 border-r border-team-teal/20' },
              { label: 'TBD', value: tbd,    cls: 'text-muted-foreground' },
            ].map(({ label, value, cls }) => (
              <div key={label} className={`flex-1 flex flex-col items-center justify-center py-3 ${cls}`}>
                <span className="font-heading text-2xl md:text-3xl leading-none">{value}</span>
                <span className="font-heading text-xs tracking-widest mt-1 opacity-70">{label}</span>
              </div>
            ))}
          </div>
        );
      })()}

      <div className="space-y-3">
        {games.map((game, idx) => (
          <div
            key={game.id}
            className="group relative flex flex-col sm:flex-row sm:items-center gap-4 p-5 bg-card border border-border border-l-2 border-l-team-teal/30 rounded hover:border-team-teal/60 hover:border-l-team-teal hover:bg-team-teal/5 transition-all duration-200"
          >
            <div className={`absolute left-0 top-0 bottom-0 w-1 rounded-l transition-all duration-200 ${
              game.result === 'win' ? 'bg-team-teal' :
              game.result === 'loss' ? 'bg-red-600' :
              'bg-border'
            }`} />

            <div className="hidden sm:flex items-center justify-center w-10 h-10 rounded-sm bg-muted/40 border border-border shrink-0 ml-2">
              <span className="font-heading text-lg text-muted-foreground">{idx + 1}</span>
            </div>

            <div className="flex-1 ml-2 sm:ml-0">
              <div className="flex flex-wrap items-center gap-3 mb-1">
                <span className="flex items-center gap-1.5 text-team-teal font-body text-sm font-semibold">
                  <Calendar className="w-3.5 h-3.5" />
                  {game.date}
                </span>
                <span className="flex items-center gap-1.5 text-muted-foreground font-body text-sm">
                  <Clock className="w-3.5 h-3.5" />
                  {game.time}
                </span>
              </div>
              <div className="font-heading text-2xl text-team-white">
                {game.opponent && game.opponent.toUpperCase() !== 'TBD'
                  ? `vs. ${game.opponent}`
                  : 'Opponent TBD'}
              </div>
              <div className="flex items-center gap-1.5 mt-1">
                <MapPin className="w-3.5 h-3.5 text-muted-foreground" />
                <span className="text-muted-foreground font-body text-sm">
                  Brunswick Auto Mall Arena
                </span>
              </div>
            </div>

            <div className="flex items-center gap-1.5 ml-2 sm:ml-0">
              <span className={`font-heading text-base tracking-wider ${
                game.home ? 'text-team-teal' : 'text-muted-foreground'
              }`}>
                {game.home ? 'HOME' : 'AWAY'}
              </span>
            </div>

            <div className="ml-2 sm:ml-0">
              <ResultBadge result={game.result} />
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
