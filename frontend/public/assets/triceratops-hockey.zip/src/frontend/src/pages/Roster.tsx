import { useState, useEffect } from 'react';
import { User } from 'lucide-react';
import { getPlayers, type Player } from '../utils/dataStore';

function positionColor(position: string): string {
  switch (position.toLowerCase()) {
    case 'goalie':  return 'text-yellow-400 border-yellow-600/50 bg-yellow-900/20';
    case 'defense': return 'text-blue-400 border-blue-600/50 bg-blue-900/20';
    case 'forward': return 'text-team-teal border-team-teal/50 bg-team-teal/10';
    default:        return 'text-muted-foreground border-border bg-muted/20';
  }
}

function PlayerCard({ player }: { player: Player }) {
  const posClass = positionColor(player.position);
  return (
    <div className="group relative flex items-center gap-4 p-4 bg-card border border-border rounded hover:border-team-teal/60 hover:bg-team-teal/10 transition-all duration-200">
      {/* Headshot */}
      <div className="shrink-0">
        {player.photo ? (
          <img
            src={player.photo}
            alt={player.name}
            className="w-14 h-14 rounded-full object-cover border-2 border-team-teal/50"
          />
        ) : (
          <div className="w-14 h-14 rounded-full bg-team-teal/10 border-2 border-team-teal/30 flex items-center justify-center group-hover:border-team-teal/60 transition-colors duration-200">
            <User className="w-6 h-6 text-team-teal/60" />
          </div>
        )}
      </div>
      {/* Number box */}
      <div className="shrink-0 w-14 h-14 flex items-center justify-center bg-team-black border-2 border-team-teal/30 rounded-sm group-hover:border-team-teal transition-colors duration-200">
        <span className="font-heading text-2xl text-team-teal leading-none">
          #{player.number}
        </span>
      </div>
      <div className="flex-1 min-w-0">
        <div className="font-heading text-xl text-team-white truncate">{player.name}</div>
        <div className="flex items-center gap-1.5 mt-0.5">
          <User className="w-3 h-3 text-muted-foreground shrink-0" />
          <span className="text-muted-foreground font-body text-sm truncate">{player.hometown}</span>
        </div>
        {(player.height || player.weight || player.age) && (
          <div className="flex items-center gap-3 mt-0.5 text-muted-foreground font-body text-xs">
            {player.height && <span>{player.height}</span>}
            {player.weight && <span>{player.weight}</span>}
            {player.age && <span>{player.age} yrs</span>}
          </div>
        )}
      </div>
      <div className={`shrink-0 px-3 py-1 rounded-sm border font-heading text-sm tracking-widest ${posClass}`}>
        {player.position.toUpperCase()}
      </div>
    </div>
  );
}

export default function Roster() {
  const [players, setPlayers] = useState<Player[]>(() => getPlayers());

  useEffect(() => {
    function onUpdate() {
      setPlayers(getPlayers());
    }
    window.addEventListener('storage', onUpdate);
    window.addEventListener('triceratops:update', onUpdate);
    return () => {
      window.removeEventListener('storage', onUpdate);
      window.removeEventListener('triceratops:update', onUpdate);
    };
  }, []);

  const goalies  = players.filter(p => p.position.toLowerCase() === 'goalie');
  const defense  = players.filter(p => p.position.toLowerCase() === 'defense');
  const forwards = players.filter(p => p.position.toLowerCase() === 'forward');
  const others   = players.filter(p => !['goalie', 'defense', 'forward'].includes(p.position.toLowerCase()));

  const groups = [
    { label: 'Goalies',  players: goalies },
    { label: 'Defense',  players: defense },
    { label: 'Forwards', players: forwards },
    ...(others.length > 0 ? [{ label: 'Other', players: others }] : []),
  ].filter(g => g.players.length > 0);

  return (
    <section className="container mx-auto px-4 py-10 bg-gradient-to-b from-team-teal/5 to-transparent">
      <div className="mb-8">
        <div className="flex items-center gap-3 mb-2">
          <div className="h-8 w-1.5 bg-team-teal" />
          <h2 className="font-heading text-4xl md:text-5xl text-team-white">Team Roster</h2>
        </div>
        <p className="text-muted-foreground ml-5 font-body">
          2024–2025 Season · {players.length} Players
        </p>
      </div>

      <div className="space-y-8">
        {groups.map((group) => (
          <div key={group.label}>
            <div className="flex items-center gap-2 mb-3">
              <span className="font-heading text-sm tracking-widest text-team-teal border border-team-teal/40 px-2 py-0.5 rounded-sm bg-team-teal/10">
                {group.label.toUpperCase()}
              </span>
              <div className="flex-1 h-px bg-border" />
              <span className="text-muted-foreground font-body text-sm">{group.players.length}</span>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
              {group.players
                .slice()
                .sort((a, b) => a.number - b.number)
                .map((player) => (
                  <PlayerCard key={player.id} player={player} />
                ))}
            </div>
          </div>
        ))}
      </div>
    </section>
  );
}
