import { Heart } from 'lucide-react';

export default function Footer() {
  const year = new Date().getFullYear();
  const appId = encodeURIComponent(typeof window !== 'undefined' ? window.location.hostname : 'triceratops-hockey');

  return (
    <footer className="mt-auto bg-team-black border-t border-border">
      <div className="container mx-auto px-4 py-6">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3">
          {/* Team info */}
          <div className="text-center sm:text-left">
            <p className="font-heading text-sm text-team-teal tracking-widest">TRICERATOPS HOCKEY</p>
            <p className="text-muted-foreground text-xs font-body mt-0.5">
              BAMAHL · Brunswick Auto Mart Adult Hockey League · {year}
            </p>
          </div>

          {/* Attribution */}
          <div className="text-center sm:text-right">
            <p className="text-muted-foreground text-xs font-body flex items-center gap-1 justify-center sm:justify-end">
              Built with{' '}
              <Heart className="w-3 h-3 text-team-teal fill-team-teal" />
              {' '}using{' '}
              <a
                href={`https://caffeine.ai/?utm_source=Caffeine-footer&utm_medium=referral&utm_content=${appId}`}
                target="_blank"
                rel="noopener noreferrer"
                className="text-team-teal hover:text-team-teal-light transition-colors underline underline-offset-2"
              >
                caffeine.ai
              </a>
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
}
