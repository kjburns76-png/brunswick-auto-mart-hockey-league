import React, { useState } from 'react';
import { Eye, EyeOff, Lock } from 'lucide-react';

interface PasswordGateProps {
  onAuthenticated: () => void;
  correctPassword: string;
}

export default function PasswordGate({ onAuthenticated, correctPassword }: PasswordGateProps) {
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (password === correctPassword) {
      // Store in sessionStorage so useActor can pick it up on re-initialization
      sessionStorage.setItem('caffeineAdminToken', password);
      setError('');
      onAuthenticated();
    } else {
      setError('Incorrect password. Please try again.');
      setPassword('');
    }
  };

  return (
    <div className="min-h-screen bg-team-black flex items-center justify-center px-4">
      <div className="w-full max-w-sm bg-black/70 border border-team-teal/30 rounded-2xl p-8 shadow-teal-glow">
        <div className="flex flex-col items-center mb-6">
          <div className="w-14 h-14 rounded-full bg-team-teal/10 border border-team-teal/40 flex items-center justify-center mb-3">
            <Lock className="w-7 h-7 text-team-teal" />
          </div>
          <h2 className="text-xl font-black text-white uppercase tracking-widest">Admin Access</h2>
          <p className="text-white/40 text-sm mt-1">Enter the admin password to continue</p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="relative">
            <input
              type={showPassword ? 'text' : 'password'}
              value={password}
              onChange={e => setPassword(e.target.value)}
              placeholder="Password"
              className="w-full px-4 py-3 pr-12 rounded-lg border border-team-teal/40 bg-black text-white placeholder:text-white/30 focus:outline-none focus:border-team-teal text-sm"
            />
            <button
              type="button"
              onClick={() => setShowPassword(v => !v)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-white/40 hover:text-white/70 transition"
              tabIndex={-1}
            >
              {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
            </button>
          </div>

          {error && (
            <p className="text-red-400 text-xs text-center">{error}</p>
          )}

          <button
            type="submit"
            className="w-full py-3 bg-team-teal text-black font-bold rounded-lg hover:bg-team-teal/80 transition uppercase tracking-wider text-sm"
          >
            Unlock
          </button>
        </form>
      </div>
    </div>
  );
}
