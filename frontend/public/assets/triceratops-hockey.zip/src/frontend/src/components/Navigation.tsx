type Tab = 'schedule' | 'roster' | 'stats' | 'news' | 'admin';

interface NavigationProps {
  activeTab: Tab;
  onTabChange: (tab: Tab) => void;
}

const tabs: { id: Tab; label: string }[] = [
  { id: 'schedule', label: 'Schedule' },
  { id: 'roster', label: 'Roster' },
  { id: 'stats', label: 'Stats' },
  { id: 'news', label: 'News' },
  { id: 'admin', label: 'Admin' },
];

export default function Navigation({ activeTab, onTabChange }: NavigationProps) {
  return (
    <nav className="sticky top-0 z-50 bg-team-black border-b-2 border-team-teal shadow-teal">
      <div className="container mx-auto px-4">
        <div className="flex items-stretch overflow-x-auto">
          {tabs.map((tab) => {
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                type="button"
                onClick={() => onTabChange(tab.id)}
                className={`
                  relative font-heading text-lg md:text-xl tracking-widest px-5 md:px-8 py-4 whitespace-nowrap
                  transition-all duration-200 border-b-4 focus:outline-none
                  ${isActive
                    ? 'text-team-teal border-team-teal bg-team-teal/20 drop-shadow-[0_0_8px_oklch(0.72_0.14_195_/_0.4)]'
                    : 'text-team-white/60 border-transparent hover:text-team-white hover:bg-team-teal/10 hover:border-team-teal/40'
                  }
                `}
              >
                {tab.label}
                {isActive && (
                  <span className="absolute bottom-0 left-1/2 -translate-x-1/2 w-2 h-2 bg-team-teal rotate-45 translate-y-1/2" />
                )}
              </button>
            );
          })}
        </div>
      </div>
    </nav>
  );
}
