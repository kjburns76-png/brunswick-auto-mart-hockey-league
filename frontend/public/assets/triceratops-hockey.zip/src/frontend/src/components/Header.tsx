import { useState, useEffect } from 'react';
import { IceCream2 } from 'lucide-react';
import { getSeason } from '../utils/dataStore';

const LOGO_SRC = '/assets/generated/triceratops-logo.dim_400x400.jpg';

export default function Header() {
  const [season, setSeason] = useState(() => getSeason());

  useEffect(() => {
    function onUpdate() {
      setSeason(getSeason());
    }
    window.addEventListener('triceratops:update', onUpdate);
    return () => window.removeEventListener('triceratops:update', onUpdate);
  }, []);

  return (
    <header className="relative overflow-hidden bg-team-black">
      {/* Rink background */}
      <div
        className="absolute inset-0 bg-cover bg-center opacity-20"
        style={{ backgroundImage: "url('/assets/generated/rink-bg.dim_1920x1080.png')" }}
      />
      {/* Teal gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-team-black via-transparent to-team-black" />
      <div className="absolute inset-0 bg-gradient-to-r from-team-black via-transparent to-team-black" />
      <div className="absolute inset-0 bg-gradient-to-br from-team-teal/20 via-transparent to-team-teal/10" />

      {/* Decorative teal lines */}
      <div className="absolute top-0 left-0 right-0 h-1 bg-team-teal" />
      <div className="absolute bottom-0 left-0 right-0 h-0.5 bg-team-teal opacity-50" />

      <div className="relative container mx-auto px-4 py-10 md:py-16">
        <div className="flex flex-col md:flex-row items-center gap-6 md:gap-10">
          {/* Logo */}
          <div className="shrink-0">
            <div className="relative w-32 h-32 md:w-44 md:h-44">
              <div className="absolute inset-0 rounded-full bg-team-teal opacity-20 blur-xl" />
              <img
                src={LOGO_SRC}
                alt="Triceratops Hockey Logo"
                className="relative w-full h-full object-contain drop-shadow-[0_0_20px_oklch(0.72_0.14_195_/_0.6)]"
              />
            </div>
          </div>

          {/* Team Info */}
          <div className="text-center md:text-left">
            {/* League badge */}
            <div className="inline-flex items-center gap-2 mb-3 px-3 py-1 border border-team-teal/40 rounded-sm bg-team-teal/10">
              <IceCream2 className="w-3 h-3 text-team-teal" />
              <span className="font-heading text-xs tracking-widest text-team-teal font-semibold">
                BAMHL · Brunswick Auto Mart Hockey League
              </span>
            </div>

            <h1 className="font-heading text-5xl md:text-7xl lg:text-8xl leading-none tracking-wide">
              <span className="text-team-teal font-black drop-shadow-[0_0_16px_oklch(0.72_0.14_195_/_0.8)]">TRICERATOPS</span>
              <br />
              <span className="text-team-white font-bold">HOCKEY</span>
            </h1>

            {/* Season + accent bar */}
            <div className="flex items-center gap-3 mt-4 justify-center md:justify-start">
              <div className="h-1 w-16 bg-team-teal" />
              <span className="font-heading text-xs tracking-widest text-team-teal/80 font-semibold">
                {season} SEASON
              </span>
              <div className="h-1 w-4 bg-team-teal/50" />
              <div className="h-1 w-2 bg-team-teal/25" />
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
