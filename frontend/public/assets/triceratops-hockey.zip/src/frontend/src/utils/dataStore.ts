// dataStore.ts — all app data stored in localStorage, no backend calls

export type GameResult = 'win' | 'loss' | 'tbd';

export interface Game {
  id: string;
  date: string;
  time: string;
  opponent: string;
  home: boolean;
  result: GameResult;
}

export interface Player {
  id: string;
  number: number;
  name: string;
  position: string;
  hometown: string;
  photo?: string;
  height?: string;
  weight?: string;
  age?: number;
}

export interface StatEntry {
  playerId: string;
  name: string;
  gamesPlayed: number;
  goals: number;
  assists: number;
  points: number;
  pim: number;
}

export interface NewsItem {
  id: string;
  title: string;
  body: string;
  publishedAt: string;
}

// ─── Default seed data ───────────────────────────────────────────────────────

const DEFAULT_GAMES: Game[] = Array.from({ length: 15 }, (_, i) => ({
  id: `game-${i + 1}`,
  date: 'TBD',
  time: 'TBD',
  opponent: 'TBD',
  home: true,
  result: 'tbd',
}));

const DEFAULT_PLAYERS: Player[] = [
  { id: 'p1',  number: 1,  name: 'TBD', position: 'Goalie',  hometown: 'TBD' },
  { id: 'p2',  number: 12, name: 'Kellen Burns',    position: 'Forward', hometown: 'Elyria, OH' },
  { id: 'p3',  number: 55, name: 'Andrew Post',     position: 'Forward', hometown: 'Avon Lake, OH' },
  { id: 'p4',  number: 7,  name: 'TBD', position: 'Forward', hometown: 'TBD' },
  { id: 'p5',  number: 8,  name: 'TBD', position: 'Forward', hometown: 'TBD' },
  { id: 'p6',  number: 9,  name: 'TBD', position: 'Forward', hometown: 'TBD' },
  { id: 'p7',  number: 10, name: 'TBD', position: 'Forward', hometown: 'TBD' },
  { id: 'p8',  number: 24, name: 'Joseph Janscura', position: 'Defense', hometown: 'Lorain, OH' },
  { id: 'p9',  number: 3,  name: 'TBD', position: 'Defense', hometown: 'TBD' },
  { id: 'p10', number: 4,  name: 'TBD', position: 'Defense', hometown: 'TBD' },
  { id: 'p11', number: 5,  name: 'TBD', position: 'Defense', hometown: 'TBD' },
];

function buildDefaultStats(players: Player[]): StatEntry[] {
  return players.map(p => ({
    playerId: p.id,
    name: p.name,
    gamesPlayed: 0,
    goals: 0,
    assists: 0,
    points: 0,
    pim: 0,
  }));
}

const DEFAULT_NEWS: NewsItem[] = [
  {
    id: 'news-1',
    title: 'Welcome to the 2026–2027 BAMHL Season!',
    body: 'The Triceratops Hockey Club is excited to kick off another great season in the Brunswick Auto Mart Hockey League. Stay tuned for schedule updates, roster announcements, and game recaps throughout the year.',
    publishedAt: 'February 2026',
  },
];

// ─── Storage keys ─────────────────────────────────────────────────────────────

const KEYS = {
  games: 'triceratops_games',
  players: 'triceratops_players',
  stats: 'triceratops_stats',
  news: 'triceratops_news',
  season: 'triceratops_season',
};

// ─── Generic helpers ──────────────────────────────────────────────────────────

function load<T>(key: string, defaults: T): T {
  try {
    const raw = localStorage.getItem(key);
    if (raw) return JSON.parse(raw) as T;
  } catch {
    // ignore parse errors
  }
  return defaults;
}

function save<T>(key: string, data: T): void {
  localStorage.setItem(key, JSON.stringify(data));
}

// ─── Public API ───────────────────────────────────────────────────────────────

export function getGames(): Game[] {
  return load<Game[]>(KEYS.games, DEFAULT_GAMES);
}
export function saveGames(games: Game[]): void {
  save(KEYS.games, games);
}

export function getPlayers(): Player[] {
  return load<Player[]>(KEYS.players, DEFAULT_PLAYERS);
}
export function savePlayers(players: Player[]): void {
  save(KEYS.players, players);
  // sync stats names when players change
  const stats = getStats();
  const updated = stats.map(s => {
    const p = players.find(pl => pl.id === s.playerId);
    return p ? { ...s, name: p.name } : s;
  });
  // add missing players to stats
  players.forEach(p => {
    if (!updated.find(s => s.playerId === p.id)) {
      updated.push({ playerId: p.id, name: p.name, gamesPlayed: 0, goals: 0, assists: 0, points: 0, pim: 0 });
    }
  });
  // remove stats for deleted players
  const validIds = new Set(players.map(p => p.id));
  const filtered = updated.filter(s => validIds.has(s.playerId));
  save(KEYS.stats, filtered);
}

export function getStats(): StatEntry[] {
  const players = load<Player[]>(KEYS.players, DEFAULT_PLAYERS);
  return load<StatEntry[]>(KEYS.stats, buildDefaultStats(players));
}
export function saveStats(stats: StatEntry[]): void {
  save(KEYS.stats, stats);
}

export function getNews(): NewsItem[] {
  return load<NewsItem[]>(KEYS.news, DEFAULT_NEWS);
}
export function saveNews(news: NewsItem[]): void {
  save(KEYS.news, news);
}

export function getSeason(): string {
  return localStorage.getItem(KEYS.season) ?? '2026-2027';
}
export function saveSeason(season: string): void {
  localStorage.setItem(KEYS.season, season);
}

export function genId(): string {
  return `${Date.now()}-${Math.random().toString(36).slice(2, 7)}`;
}
