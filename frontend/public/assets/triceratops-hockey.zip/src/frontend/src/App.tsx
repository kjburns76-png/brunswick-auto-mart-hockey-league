import { useState } from 'react';
import Header from './components/Header';
import Navigation from './components/Navigation';
import Footer from './components/Footer';
import Schedule from './pages/Schedule';
import Roster from './pages/Roster';
import Stats from './pages/Stats';
import News from './pages/News';
import Admin from './pages/Admin';

type Tab = 'schedule' | 'roster' | 'stats' | 'news' | 'admin';

export default function App() {
  const [activeTab, setActiveTab] = useState<Tab>('schedule');

  return (
    <div className="min-h-screen flex flex-col bg-background stripe-bg">
      <Header />
      <Navigation activeTab={activeTab} onTabChange={setActiveTab} />
      <main className="flex-1">
        {activeTab === 'schedule' && <Schedule />}
        {activeTab === 'roster'   && <Roster />}
        {activeTab === 'stats'    && <Stats />}
        {activeTab === 'news'     && <News />}
        {activeTab === 'admin'    && <Admin />}
      </main>
      <Footer />
    </div>
  );
}
