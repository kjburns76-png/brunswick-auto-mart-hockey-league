const ADMIN_PASSWORD = 'Bubbakellen2!';

export function useAdminActor() {
  const token = sessionStorage.getItem('caffeineAdminToken');
  const isAdmin = token === ADMIN_PASSWORD;
  return { isAdmin };
}
