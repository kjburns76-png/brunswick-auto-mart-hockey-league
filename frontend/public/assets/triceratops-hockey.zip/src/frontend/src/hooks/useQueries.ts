// Backend no longer provides hockey-specific data methods.
// This file is kept minimal; all hockey data is now static in the page components.
export {};
