// Backend no longer provides hockey-specific mutation methods.
// This file is kept minimal; admin operations are now handled via static data.
export {};
